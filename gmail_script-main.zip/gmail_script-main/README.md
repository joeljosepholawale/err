# Gmail_script
Simple script to send mails via Gmail
